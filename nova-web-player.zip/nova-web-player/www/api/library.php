<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/nextcloud.php';
require_once __DIR__ . '/../includes/subsonic.php';

$user = nova_require_login();
$db = nova_db();
$stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = ?');
$stmt->execute([$user['id']]);
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$settings || $settings['source_type'] === '') {
    nova_send_json(['error' => 'No music source configured yet — add one in Settings first.', 'tracks' => []], 200);
}

try {
    if ($settings['source_type'] === 'nextcloud') {
        if ($settings['nc_share_url'] === '') nova_send_json(['error' => 'NextCloud share URL not set', 'tracks' => []]);
        $client = new NovaNextCloudClient($settings['nc_share_url'], $settings['nc_share_password']);
        $paths = $client->listNovaFiles();
        $tracks = array_map(fn($p) => ['id' => $p, 'path' => $p, 'name' => basename($p)], $paths);
        nova_send_json(['tracks' => $tracks]);
    } elseif ($settings['source_type'] === 'subsonic') {
        if ($settings['subsonic_base_url'] === '') nova_send_json(['error' => 'Subsonic server URL not set', 'tracks' => []]);
        $client = new NovaSubsonicClient($settings['subsonic_base_url'], $settings['subsonic_username'], $settings['subsonic_password']);
        $found = $client->listNovaFiles();
        $tracks = array_map(fn($f) => ['id' => $f['id'], 'path' => $f['path'], 'name' => basename($f['path'])], $found);
        nova_send_json([
            'tracks' => $tracks,
            'note' => count($tracks) === 0
                ? 'No .nova files found. Most Subsonic-compatible servers only index recognized audio formats — this is expected unless your server has been specifically configured to expose unrecognized file types.'
                : null,
        ]);
    }
} catch (Throwable $e) {
    nova_send_json(['error' => 'Could not reach your music source: ' . $e->getMessage(), 'tracks' => []]);
}

nova_send_json(['error' => 'Unknown source type', 'tracks' => []]);
