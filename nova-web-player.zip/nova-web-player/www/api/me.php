<?php
require_once __DIR__ . '/../includes/auth.php';
$user = nova_current_user();
if (!$user) nova_send_json(['loggedIn' => false]);
nova_send_json(['loggedIn' => true, 'id' => $user['id'], 'username' => $user['username'], 'is_admin' => (bool)$user['is_admin']]);
