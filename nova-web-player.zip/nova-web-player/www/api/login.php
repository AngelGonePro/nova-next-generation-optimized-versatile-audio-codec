<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') nova_send_json(['error' => 'POST only'], 405);

$body = nova_json_body();
$username = trim($body['username'] ?? '');
$password = $body['password'] ?? '';

if ($username === '' || $password === '') {
    nova_send_json(['error' => 'Username and password required'], 400);
}

$stmt = nova_db()->prepare('SELECT id, username, password_hash, is_admin FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['password_hash'])) {
    // Deliberately identical error for "no such user" and "wrong password" — don't
    // let a login attempt be used to enumerate which usernames exist.
    nova_send_json(['error' => 'Invalid username or password'], 401);
}

nova_start_session();
session_regenerate_id(true); // fresh session id on privilege change, standard practice against session fixation
$_SESSION['user_id'] = $user['id'];

nova_send_json(['id' => $user['id'], 'username' => $user['username'], 'is_admin' => (bool)$user['is_admin']]);
