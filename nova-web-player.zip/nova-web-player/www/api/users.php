<?php
require_once __DIR__ . '/../includes/auth.php';
$admin = nova_require_admin();
$db = nova_db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $db->query('SELECT id, username, is_admin, created_at FROM users ORDER BY username');
    $users = array_map(function ($r) {
        return ['id' => (int)$r['id'], 'username' => $r['username'], 'is_admin' => (bool)$r['is_admin'], 'created_at' => $r['created_at']];
    }, $stmt->fetchAll(PDO::FETCH_ASSOC));
    nova_send_json(['users' => $users]);
}

if ($method === 'POST') {
    $body = nova_json_body();
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';
    $isAdmin = !empty($body['is_admin']) ? 1 : 0;

    if ($username === '' || strlen($password) < 8) {
        nova_send_json(['error' => 'Username required and password must be at least 8 characters'], 400);
    }
    try {
        $stmt = $db->prepare('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $isAdmin]);
        nova_send_json(['id' => (int)$db->lastInsertId(), 'username' => $username, 'is_admin' => (bool)$isAdmin], 201);
    } catch (PDOException $e) {
        // UNIQUE constraint on username is the only realistic failure mode here
        nova_send_json(['error' => 'That username is already taken'], 409);
    }
}

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) nova_send_json(['error' => 'Missing or invalid id'], 400);
    if ($id === (int)$admin['id']) {
        nova_send_json(['error' => "Can't delete your own account while logged in as it — log in as another admin first"], 400);
    }

    // Don't allow removing the last remaining admin account, even by another admin —
    // that would lock everyone out of user management permanently.
    $target = $db->prepare('SELECT is_admin FROM users WHERE id = ?');
    $target->execute([$id]);
    $row = $target->fetch(PDO::FETCH_ASSOC);
    if (!$row) nova_send_json(['error' => 'User not found'], 404);
    if ($row['is_admin']) {
        $adminCount = (int)$db->query('SELECT COUNT(*) FROM users WHERE is_admin = 1')->fetchColumn();
        if ($adminCount <= 1) nova_send_json(['error' => 'Cannot delete the last remaining admin account'], 400);
    }

    $db->prepare('DELETE FROM users WHERE id = ?')->execute([$id]); // playlists/settings cascade via FK
    nova_send_json(['ok' => true]);
}

nova_send_json(['error' => 'Method not allowed'], 405);
