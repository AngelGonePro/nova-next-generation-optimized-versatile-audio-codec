<?php
require_once __DIR__ . '/../includes/auth.php';
$user = nova_require_login();
$db = nova_db();
$method = $_SERVER['REQUEST_METHOD'];

function nova_load_playlists(PDO $db, int $userId): array {
    $stmt = $db->prepare('SELECT id, name FROM playlists WHERE user_id = ? ORDER BY name');
    $stmt->execute([$userId]);
    $playlists = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($playlists as $pl) {
        $t = $db->prepare('SELECT track_path FROM playlist_tracks WHERE playlist_id = ? ORDER BY position');
        $t->execute([$pl['id']]);
        $out[] = ['id' => (int)$pl['id'], 'name' => $pl['name'], 'tracks' => $t->fetchAll(PDO::FETCH_COLUMN)];
    }
    return $out;
}

if ($method === 'GET') {
    nova_send_json(['playlists' => nova_load_playlists($db, $user['id'])]);
}

if ($method === 'POST') {
    // Whole-playlist upsert: {id?, name, tracks: [path, ...]}. id omitted/0 => create new.
    $body = nova_json_body();
    $name = trim($body['name'] ?? '');
    $tracks = is_array($body['tracks'] ?? null) ? $body['tracks'] : [];
    if ($name === '') nova_send_json(['error' => 'Playlist name required'], 400);

    $db->beginTransaction();
    try {
        $id = (int)($body['id'] ?? 0);
        if ($id > 0) {
            $own = $db->prepare('SELECT id FROM playlists WHERE id = ? AND user_id = ?');
            $own->execute([$id, $user['id']]);
            if (!$own->fetch()) { $db->rollBack(); nova_send_json(['error' => 'Playlist not found'], 404); }
            $db->prepare('UPDATE playlists SET name = ? WHERE id = ?')->execute([$name, $id]);
            $db->prepare('DELETE FROM playlist_tracks WHERE playlist_id = ?')->execute([$id]);
        } else {
            $stmt = $db->prepare('INSERT INTO playlists (user_id, name) VALUES (?, ?)');
            $stmt->execute([$user['id'], $name]);
            $id = (int)$db->lastInsertId();
        }
        $ins = $db->prepare('INSERT INTO playlist_tracks (playlist_id, track_path, position) VALUES (?, ?, ?)');
        foreach (array_values($tracks) as $pos => $trackPath) {
            $ins->execute([$id, $trackPath, $pos]);
        }
        $db->commit();
        nova_send_json(['id' => $id, 'ok' => true]);
    } catch (PDOException $e) {
        $db->rollBack();
        if (strpos($e->getMessage(), 'UNIQUE') !== false) nova_send_json(['error' => 'You already have a playlist with that name'], 409);
        nova_send_json(['error' => 'Could not save playlist'], 500);
    }
}

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) nova_send_json(['error' => 'Missing or invalid id'], 400);
    $stmt = $db->prepare('DELETE FROM playlists WHERE id = ? AND user_id = ?'); // ownership check baked into the WHERE
    $stmt->execute([$id, $user['id']]);
    if ($stmt->rowCount() === 0) nova_send_json(['error' => 'Playlist not found'], 404);
    nova_send_json(['ok' => true]);
}

nova_send_json(['error' => 'Method not allowed'], 405);
