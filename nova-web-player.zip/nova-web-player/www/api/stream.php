<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/nextcloud.php';
require_once __DIR__ . '/../includes/subsonic.php';

// PHP's own max_execution_time (commonly 30s by default in many configs) would
// independently truncate a large file transfer regardless of curl's own timeout
// settings — remove that ceiling specifically for this script, since streaming a
// multi-hundred-MB file can legitimately take longer than a typical script's default.
set_time_limit(0);

$user = nova_require_login();
$db = nova_db();
$stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = ?');
$stmt->execute([$user['id']]);
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

$trackId = $_GET['id'] ?? '';
if ($trackId === '' || !$settings || $settings['source_type'] === '') {
    http_response_code(400);
    exit;
}

header('Content-Type: application/octet-stream');
header('Cache-Control: private, max-age=3600'); // browser can cache a decoded-once track for the session

$rangeHeader = $_SERVER['HTTP_RANGE'] ?? null;

try {
    if ($settings['source_type'] === 'nextcloud') {
        // For NextCloud, $trackId IS the relative path (that's what library.php returned as 'id').
        $client = new NovaNextCloudClient($settings['nc_share_url'], $settings['nc_share_password']);
        $client->streamFile($trackId, $rangeHeader);
    } elseif ($settings['source_type'] === 'subsonic') {
        // For Subsonic, $trackId is the server's own song id.
        $client = new NovaSubsonicClient($settings['subsonic_base_url'], $settings['subsonic_username'], $settings['subsonic_password']);
        $client->streamFile($trackId, $rangeHeader);
    } else {
        http_response_code(400);
    }
} catch (Throwable $e) {
    http_response_code(502);
}
