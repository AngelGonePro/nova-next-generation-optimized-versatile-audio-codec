<?php
require_once __DIR__ . '/../includes/auth.php';
$user = nova_require_login();
$db = nova_db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $db->prepare('SELECT source_type, nc_share_url, subsonic_base_url, subsonic_username FROM user_settings WHERE user_id = ?');
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // Passwords/share-passwords are deliberately never sent back to the client once saved —
    // the browser doesn't need them again (the server proxies every request), and there's
    // no reason to keep echoing a secret back on every settings load.
    nova_send_json($row ?: ['source_type' => '', 'nc_share_url' => '', 'subsonic_base_url' => '', 'subsonic_username' => '']);
}

if ($method === 'POST') {
    $body = nova_json_body();
    $sourceType = in_array($body['source_type'] ?? '', ['nextcloud', 'subsonic'], true) ? $body['source_type'] : '';

    $stmt = $db->prepare('
        INSERT INTO user_settings (user_id, source_type, nc_share_url, nc_share_password, subsonic_base_url, subsonic_username, subsonic_password, updated_at)
        VALUES (:uid, :st, :ncu, :ncp, :sbu, :su, :sp, datetime("now"))
        ON CONFLICT(user_id) DO UPDATE SET
            source_type = :st, nc_share_url = :ncu, nc_share_password = :ncp,
            subsonic_base_url = :sbu, subsonic_username = :su, subsonic_password = :sp,
            updated_at = datetime("now")
    ');
    $stmt->execute([
        ':uid' => $user['id'],
        ':st' => $sourceType,
        ':ncu' => trim($body['nc_share_url'] ?? ''),
        ':ncp' => $body['nc_share_password'] ?? '',
        ':sbu' => trim($body['subsonic_base_url'] ?? ''),
        ':su' => trim($body['subsonic_username'] ?? ''),
        ':sp' => $body['subsonic_password'] ?? '',
    ]);
    nova_send_json(['ok' => true]);
}

nova_send_json(['error' => 'Method not allowed'], 405);
