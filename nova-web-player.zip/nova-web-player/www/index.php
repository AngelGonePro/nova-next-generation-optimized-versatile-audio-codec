<?php
// nginx's default `index` directive looks for index.php/index.html at the web root —
// web.html isn't in that list, so visiting the bare domain 403s with "directory index
// forbidden" instead of finding it. This stub exists purely to redirect / to /web.html.
//
// Deliberately NOT fixed by editing nginx/conf.d/default.conf instead: the egg's
// auto-update system explicitly overwrites nginx configs on update, so a fix living
// there would silently break again on the next update. This file isn't touched by
// that process at all.
header('Location: web.html');
exit;
