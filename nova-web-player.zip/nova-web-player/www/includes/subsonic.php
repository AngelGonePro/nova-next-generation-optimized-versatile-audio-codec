<?php
// Talks to a Subsonic-compatible server (Navidrome, Airsonic, etc.) using the standard
// token-based auth (salted MD5, no plaintext password on the wire even server-to-server).
//
// IMPORTANT, HONEST CAVEAT: Subsonic-compatible servers index media by scanning for
// recognized audio file extensions/tags. A completely custom format like .nova will very
// likely NOT be recognized or indexed by a stock server at all — meaning this path may
// return an empty library even when your NextCloud-equivalent folder structure is set up
// correctly. This isn't a bug in this client; it's a property of how those servers work.
// Treat this integration as best-effort/experimental unless you've specifically confirmed
// your server surfaces .nova files (e.g. via a custom/passthrough media type setting).

class NovaSubsonicClient {
    private string $baseUrl;
    private string $username;
    private string $password;
    private const CLIENT_NAME = 'nova-web-player';
    private const API_VERSION = '1.16.1';

    public function __construct(string $baseUrl, string $username, string $password) {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->username = $username;
        $this->password = $password;
    }

    private function authParams(): array {
        $salt = bin2hex(random_bytes(6));
        $token = md5($this->password . $salt);
        return [
            'u' => $this->username, 't' => $token, 's' => $salt,
            'v' => self::API_VERSION, 'c' => self::CLIENT_NAME, 'f' => 'json',
        ];
    }

    private function call(string $endpoint, array $extraParams = []): ?array {
        $url = $this->baseUrl . '/rest/' . $endpoint . '?' . http_build_query(array_merge($this->authParams(), $extraParams));
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_SSL_VERIFYPEER => true]);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response === false) return null;
        $data = json_decode($response, true);
        return $data['subsonic-response'] ?? null;
    }

    // Recursively walks the folder tree looking for .nova files. Returns
    // [{id, path}] — id is the Subsonic song id needed for streaming later.
    public function listNovaFiles(): array {
        $indexes = $this->call('getIndexes.view');
        if (!$indexes || ($indexes['status'] ?? '') !== 'ok') return [];
        $results = [];
        $artists = $indexes['indexes']['index'] ?? [];
        foreach ($artists as $indexGroup) {
            foreach (($indexGroup['artist'] ?? []) as $artist) {
                $this->walkDirectory((string)$artist['id'], $artist['name'] ?? '', $results);
            }
        }
        return $results;
    }

    private function walkDirectory(string $id, string $pathPrefix, array &$results, int $depth = 0): void {
        if ($depth > 8) return;
        $dir = $this->call('getMusicDirectory.view', ['id' => $id]);
        if (!$dir || ($dir['status'] ?? '') !== 'ok') return;
        foreach (($dir['directory']['child'] ?? []) as $child) {
            $name = $child['title'] ?? $child['name'] ?? '';
            $childPath = $pathPrefix . '/' . $name;
            if (!empty($child['isDir'])) {
                $this->walkDirectory((string)$child['id'], $childPath, $results, $depth + 1);
            } elseif (strtolower($child['suffix'] ?? '') === 'nova') {
                $results[] = ['id' => (string)$child['id'], 'path' => $childPath];
            }
        }
    }

    public function streamFile(string $songId, ?string $rangeHeader = null): void {
        $url = $this->baseUrl . '/rest/stream.view?' . http_build_query(array_merge($this->authParams(), ['id' => $songId, 'format' => 'raw']));
        $ch = curl_init($url);
        $headers = [];
        if ($rangeHeader) $headers[] = 'Range: ' . $rangeHeader;
        $responseHeaders = [];
        $headersSent = false;
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_TIMEOUT => 0,             // no total-duration cap — see nextcloud.php's streamFile for why
            CURLOPT_LOW_SPEED_LIMIT => 1024,
            CURLOPT_LOW_SPEED_TIME => 30,
            CURLOPT_HEADERFUNCTION => function ($ch, $headerLine) use (&$responseHeaders) {
                $parts = explode(':', $headerLine, 2);
                if (count($parts) === 2) $responseHeaders[strtolower(trim($parts[0]))] = trim($parts[1]);
                return strlen($headerLine);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$responseHeaders, &$headersSent) {
                if (!$headersSent) {
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    http_response_code($httpCode === 206 ? 206 : 200);
                    if (isset($responseHeaders['content-range'])) header('Content-Range: ' . $responseHeaders['content-range']);
                    if (isset($responseHeaders['content-length'])) header('Content-Length: ' . $responseHeaders['content-length']);
                    header('Accept-Ranges: bytes');
                    $headersSent = true;
                }
                echo $chunk;
                return strlen($chunk);
            },
        ]);
        $success = curl_exec($ch);
        $curlErrno = curl_errno($ch);
        $curlError = curl_error($ch);
        curl_close($ch);

        if (!$headersSent) {
            http_response_code(502);
            header('Content-Type: text/plain');
            echo 'Could not reach the Subsonic server: ' . ($curlError ?: "curl error #$curlErrno");
        }
    }
}
