<?php
require_once __DIR__ . '/db.php';

function nova_start_session(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            // 'secure' is left off here since this runs behind a reverse proxy that may
            // terminate TLS upstream — set true if you confirm the cookie only ever
            // travels over HTTPS in your deployment.
        ]);
        session_start();
    }
}

function nova_current_user(): ?array {
    nova_start_session();
    if (empty($_SESSION['user_id'])) return null;
    $stmt = nova_db()->prepare('SELECT id, username, is_admin FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { unset($_SESSION['user_id']); return null; }
    return $user;
}

function nova_require_login(): array {
    $user = nova_current_user();
    if (!$user) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Not logged in']);
        exit;
    }
    return $user;
}

function nova_require_admin(): array {
    $user = nova_require_login();
    if (!$user['is_admin']) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Admin access required']);
        exit;
    }
    return $user;
}

function nova_json_body(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function nova_send_json($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
