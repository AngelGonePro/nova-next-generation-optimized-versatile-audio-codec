<?php
// Talks to a NextCloud public share's WebDAV endpoint. This runs server-side specifically
// so the browser never needs the share password, and so we're not subject to whatever
// CORS policy the NextCloud instance does or doesn't set for arbitrary origins.
//
// Uses the classic /public.php/webdav/ endpoint (share token as Basic Auth username,
// share password as the Basic Auth password, or blank if the share has none). This
// endpoint has the longest compatibility track record across NextCloud versions. If your
// instance is NC29+ and this stops working for some future reason, the newer alternative
// is /public.php/dav/files/{token}/ with username "anonymous" and an added
// "X-Requested-With: XMLHttpRequest" header on non-GET requests.

// Pure parsing function — no network I/O — so it can be tested directly against a
// sample PROPFIND response without needing a real NextCloud server.
function nova_parse_propfind_response(string $xmlString, string $subPath): array {
    $xml = @simplexml_load_string($xmlString);
    // Must check `=== false` explicitly — SimpleXMLElement has quirky boolean conversion
    // where a valid element containing only child nodes (no direct text) can evaluate as
    // falsy under a plain `!$xml` check, even though parsing succeeded correctly.
    if ($xml === false) return [];
    $xml->registerXPathNamespace('d', 'DAV:');
    $entries = [];
    foreach ($xml->xpath('//d:response') as $r) {
        $r->registerXPathNamespace('d', 'DAV:');
        $href = (string)($r->xpath('d:href')[0] ?? '');
        $isCollection = count($r->xpath('.//d:collection')) > 0;
        $decodedHref = rawurldecode($href);
        $rel = preg_replace('#^.*?/public\.php/webdav/?#', '', $decodedHref);
        $rel = trim($rel, '/');
        if ($rel === '' || $rel === trim($subPath, '/')) continue; // the folder entry for itself
        $entries[] = ['path' => $rel, 'isDir' => $isCollection];
    }
    return $entries;
}

class NovaNextCloudClient {
    private string $baseUrl;   // e.g. https://cloud.cosmoscraft.net
    private string $token;     // the share token (the part after /s/ in the share link)
    private string $password;

    public function __construct(string $shareUrl, string $password) {
        // Accept a full share URL like https://host/s/TOKEN or https://host/index.php/s/TOKEN
        $parts = parse_url($shareUrl);
        if (!$parts || empty($parts['host'])) throw new InvalidArgumentException('Invalid share URL');
        $this->baseUrl = ($parts['scheme'] ?? 'https') . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
        $path = $parts['path'] ?? '';
        if (!preg_match('#/s/([^/]+)#', $path, $m)) throw new InvalidArgumentException('Could not find a share token in that URL (expected .../s/TOKEN)');
        $this->token = $m[1];
        $this->password = $password;
    }

    private function davUrl(string $subPath = ''): string {
        $path = ltrim($subPath, '/');
        // Encode each path segment individually — NOT the whole path at once, which
        // would incorrectly encode the '/' separators too. Filenames with spaces
        // (extremely common — "Starry Eyes - The Weeknd - 7.1-FLAC.nova") produce a
        // raw space in the URL if left unencoded, which curl correctly rejects outright
        // as CURLE_URL_MALFORMAT ("URL using bad/illegal format").
        $encoded = $path === '' ? '' : implode('/', array_map('rawurlencode', explode('/', $path)));
        return $this->baseUrl . '/public.php/webdav/' . $encoded;
    }

    private function curlBase() {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_USERPWD => $this->token . ':' . $this->password,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        return $ch;
    }

    // Recursively lists every .nova file under the share, returning relative paths.
    // The top-level call surfaces connection/auth failures as an exception (so the user
    // gets a clear error message for e.g. a mistyped share URL) — a failure in a nested
    // subfolder further down is treated as fail-soft instead, so one bad subfolder
    // doesn't erase the rest of an otherwise-working listing.
    public function listNovaFiles(string $subPath = '', int $depth = 0): array {
        if ($depth > 12) return []; // sane recursion guard against pathological share structures
        $ch = $this->curlBase();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->davUrl($subPath),
            CURLOPT_CUSTOMREQUEST => 'PROPFIND',
            CURLOPT_HTTPHEADER => ['Depth: 1', 'Content-Type: application/xml'],
            CURLOPT_POSTFIELDS => '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/></d:prop></d:propfind>',
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false || $httpCode >= 300) {
            if ($depth === 0) {
                $reason = $curlError ?: "server returned HTTP $httpCode";
                throw new RuntimeException("Could not reach the NextCloud share ($reason) — check the share URL and password.");
            }
            return []; // a subfolder failing shouldn't kill the whole listing
        }

        $entries = nova_parse_propfind_response($response, $subPath);
        $results = [];
        foreach ($entries as $entry) {
            if ($entry['isDir']) {
                $results = array_merge($results, $this->listNovaFiles($entry['path'], $depth + 1));
            } elseif (preg_match('/\.nova$/i', $entry['path'])) {
                $results[] = $entry['path'];
            }
        }
        return $results;
    }

    // Streams a single file's bytes directly to the HTTP response as they arrive, rather
    // than buffering the whole (potentially 100MB+) file in PHP memory first. Passes
    // through an incoming Range header so the browser can request just the first chunk
    // of a file (e.g. to read tags/artwork without downloading the whole track) or seek.
    //
    // Deliberately does NOT use curlBase()'s 30s CURLOPT_TIMEOUT here — that's a total
    // wall-clock cap appropriate for a quick PROPFIND listing, but wrong for downloading
    // a full multi-hundred-MB file, where total transfer time legitimately scales with
    // file size. A large file could get cut off mid-stream at the 30s mark with no error
    // surfaced (bytes already sent look like a normal — just truncated — response),
    // which is exactly what breaks decode() downstream. Uses stall detection instead:
    // abort only if the transfer genuinely stops making progress, not just because it's
    // a big file that legitimately takes longer than 30 seconds.
    public function streamFile(string $relPath, ?string $rangeHeader = null): void {
        $ch = curl_init();
        $headers = [];
        if ($rangeHeader) $headers[] = 'Range: ' . $rangeHeader;
        $responseHeaders = [];
        curl_setopt_array($ch, [
            CURLOPT_USERPWD => $this->token . ':' . $this->password,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_TIMEOUT => 0,             // no total-duration cap — large files can legitimately take a while
            CURLOPT_LOW_SPEED_LIMIT => 1024,  // ...but abort if we genuinely stall...
            CURLOPT_LOW_SPEED_TIME => 30,     // ...under 1KB/s sustained for 30s straight
            CURLOPT_URL => $this->davUrl($relPath),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_HEADERFUNCTION => function ($ch, $headerLine) use (&$responseHeaders) {
                $parts = explode(':', $headerLine, 2);
                if (count($parts) === 2) $responseHeaders[strtolower(trim($parts[0]))] = trim($parts[1]);
                return strlen($headerLine);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$responseHeaders, &$headersSent) {
                if (!$headersSent) {
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    http_response_code($httpCode === 206 ? 206 : 200);
                    if (isset($responseHeaders['content-range'])) header('Content-Range: ' . $responseHeaders['content-range']);
                    // Deliberately NOT forwarding Content-Length: it's declared here based on what
                    // curl EXPECTS from the upstream response, before the transfer actually
                    // completes. If the real transfer gets cut short for any reason, that
                    // declared-vs-actual mismatch makes Chrome's HTTP/2 layer treat it as a
                    // protocol violation and hard-abort the connection (ERR_HTTP2_PROTOCOL_ERROR)
                    // instead of just delivering a truncated response. Omitting it lets the
                    // response use chunked transfer encoding instead, which is self-describing —
                    // a real underlying problem then shows up as a normal short/incomplete read
                    // that the existing JS-side chunk validation already catches and reports
                    // clearly, rather than a hard browser-level crash.
                    header('Accept-Ranges: bytes');
                    $headersSent = true;
                }
                echo $chunk;
                return strlen($chunk);
            },
        ]);
        $headersSent = false;
        $success = curl_exec($ch);
        $curlErrno = curl_errno($ch);
        $curlError = curl_error($ch);
        curl_close($ch);

        // If curl failed before the write callback ever fired, $headersSent is still
        // false and the browser would otherwise get a silent 200-with-empty-body response
        // — indistinguishable from "the file is just empty." Surface the real cause instead.
        if (!$headersSent) {
            http_response_code(502);
            header('Content-Type: text/plain');
            echo 'Could not reach the NextCloud share: ' . ($curlError ?: "curl error #$curlErrno") .
                ' (URL: ' . $this->davUrl($relPath) . ')';
        }
    }
}
