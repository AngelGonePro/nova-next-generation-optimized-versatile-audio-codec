<?php
// Database connection + schema. The SQLite file lives at ../../data/app.db relative to
// this file (i.e. one level ABOVE the 'www' web root the egg's nginx serves). This is
// deliberate: nginx's root only ever points at www/, and no request path can traverse
// above a configured root, so this file is structurally unreachable over HTTP — not
// "unreachable because of an nginx rule we wrote" (the egg's auto-updater explicitly
// overwrites nginx configs on update, so a rule we added there could vanish on update).

function nova_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dataDir = dirname(__DIR__, 2) . '/data';
    if (!is_dir($dataDir)) {
        if (!mkdir($dataDir, 0700, true) && !is_dir($dataDir)) {
            throw new RuntimeException('Could not create data directory: ' . $dataDir);
        }
    }
    $dbPath = $dataDir . '/app.db';
    $isNew = !file_exists($dbPath);

    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('PRAGMA foreign_keys = ON');

    if ($isNew) {
        nova_db_init_schema($pdo);
    }
    return $pdo;
}

function nova_db_init_schema(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    ");
    $pdo->exec("
        CREATE TABLE user_settings (
            user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            source_type TEXT NOT NULL DEFAULT '',
            nc_share_url TEXT NOT NULL DEFAULT '',
            nc_share_password TEXT NOT NULL DEFAULT '',
            subsonic_base_url TEXT NOT NULL DEFAULT '',
            subsonic_username TEXT NOT NULL DEFAULT '',
            subsonic_password TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    ");
    $pdo->exec("
        CREATE TABLE playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(user_id, name)
        )
    ");
    $pdo->exec("
        CREATE TABLE playlist_tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
            track_path TEXT NOT NULL,
            position INTEGER NOT NULL
        )
    ");

    // First-run seed: create the admin account from config.php's defaults.
    // This ONLY happens because the users table is empty (fresh database).
    // After this, config.php's values are never consulted again — the database
    // is authoritative, so changing the admin's password via the UI actually sticks.
    require_once __DIR__ . '/../../config.php';
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, 1)');
    $stmt->execute([DEFAULT_ADMIN_USER, password_hash(DEFAULT_ADMIN_PASS, PASSWORD_DEFAULT)]);
}
