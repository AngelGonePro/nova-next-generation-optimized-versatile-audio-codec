<?php
// Only used ONCE — to seed the initial admin account the very first time this app runs
// (when the database doesn't exist yet). After that first run, these values are never
// read again: the admin account lives in the database from then on, so changing the
// password through the admin panel actually takes effect and isn't overridden by
// whatever stays in this file.
//
// CHANGE THE PASSWORD BELOW BEFORE FIRST DEPLOYMENT, then change it again via the
// admin panel after your first login — this file's password is a bootstrap value only,
// not an ongoing credential store.

define('DEFAULT_ADMIN_USER', 'admin');
define('DEFAULT_ADMIN_PASS', 'changeme-before-deploying');
